import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { Course } from './entities/course.entity';
import { CreateCourseDto } from './dto/create-course.dto';
import { UpdateCourseDto } from './dto/update-course.dto';
import { User } from '../users/entities/user.entity';
import { Assignment } from '../assignments/entities/assignment.entity';

@Injectable()
export class CoursesService {
  constructor(
    @InjectRepository(Course)
    private coursesRepository: Repository<Course>,
    @InjectRepository(User)
    private usersRepository: Repository<User>,
    @InjectRepository(Assignment)
    private assignmentsRepository: Repository<Assignment>,
  ) {}

  async findAll(page = 1, limit = 10, search?: string) {
    const query = this.coursesRepository.createQueryBuilder('course');

    if (search) {
      query.where(
        'course.title LIKE :search OR course.description LIKE :search',
        {
          search: `%${search}%`,
        },
      );
    }

    query.skip((page - 1) * limit).take(limit);

    const [items, total] = await query.getManyAndCount();

    return {
      items,
      total,
      page,
      limit,
    };
  }

  async findOne(id: string) {
    const course = await this.coursesRepository.findOne({
      where: { id },
      relations: ['teacher', 'assignments'],
    });
    if (!course) {
      throw new NotFoundException('Course not found');
    }
    return course;
  }

  async create(createCourseDto: CreateCourseDto, teacherId: string) {
    const teacher = await this.usersRepository.findOne({
      where: { id: teacherId },
    });
    if (!teacher) {
      throw new NotFoundException('Teacher not found');
    }
    const course = this.coursesRepository.create({
      ...createCourseDto,
      teacher,
    });
    return this.coursesRepository.save(course);
  }

  async update(
    id: string,
    updateCourseDto: UpdateCourseDto,
    teacherId: string,
  ) {
    const course = await this.coursesRepository.findOne({
      where: { id },
      relations: ['teacher'],
    });
    if (!course) {
      throw new NotFoundException('Course not found');
    }
    if (course.teacher.id !== teacherId) {
      throw new ForbiddenException('You are not allowed to update this course');
    }
    Object.assign(course, updateCourseDto);
    return this.coursesRepository.save(course);
  }

  async remove(id: string, teacherId: string) {
    const course = await this.coursesRepository.findOne({
      where: { id },
      relations: ['teacher'],
    });
    if (!course) {
      throw new NotFoundException('Course not found');
    }
    if (course.teacher.id !== teacherId) {
      throw new ForbiddenException('You are not allowed to delete this course');
    }
    return this.coursesRepository.remove(course);
  }
}
