import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinTable,
  ManyToMany,
  JoinColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Assignment } from '../../assignments/entities/assignment.entity';

@Entity('courses')
export class Course {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 100 })
  title: string;

  @Column({ length: 1000 })
  description: string;

  @Column()
  teacherId: string;

  @ManyToOne(() => User, (user) => user.teacherCourses)
  @JoinColumn({ name: 'teacherId' })
  teacher: User;

  @OneToMany(() => Assignment, (assignment) => assignment.course)
  assignments: Assignment[];

  @ManyToMany(() => User)
  @JoinTable({
    name: 'course_enrollments',
    joinColumn: { name: 'courseId', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'studentId', referencedColumnName: 'id' },
  })
  students: User[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
