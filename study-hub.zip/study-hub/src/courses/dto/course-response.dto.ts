import { ApiProperty } from '@nestjs/swagger';

class MaterialDto {
  @ApiProperty({
    description: 'Material ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  id: string;

  @ApiProperty({
    description: 'Material title',
    example: 'Lecture 1: Introduction',
  })
  title: string;

  @ApiProperty({
    description: 'Material file URL',
    example: '/uploads/materials/lecture-1.pdf',
  })
  fileUrl: string;

  @ApiProperty({
    description: 'Creation date',
    example: '2023-05-01T12:00:00Z',
  })
  createdAt: Date;
}

class AssignmentDto {
  @ApiProperty({
    description: 'Assignment ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  id: string;

  @ApiProperty({
    description: 'Assignment title',
    example: 'Homework 1',
  })
  title: string;

  @ApiProperty({
    description: 'Assignment description',
    example: 'Implement a simple calculator using JavaScript.',
  })
  description: string;

  @ApiProperty({
    description: 'Due date',
    example: '2023-05-15T23:59:59Z',
  })
  dueDate: Date;

  @ApiProperty({
    description: 'Maximum score',
    example: 100,
  })
  maxScore: number;
}

export class CourseListItemDto {
  @ApiProperty({
    description: 'Course ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  id: string;

  @ApiProperty({
    description: 'Course title',
    example: 'Introduction to Programming',
  })
  title: string;

  @ApiProperty({
    description: 'Course description',
    example:
      'This course provides an introduction to programming concepts using JavaScript.',
  })
  description: string;

  @ApiProperty({
    description: 'Teacher ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  teacherId: string;

  @ApiProperty({
    description: 'Teacher name',
    example: 'John Doe',
  })
  teacherName: string;

  @ApiProperty({
    description: 'Number of students enrolled',
    example: 25,
  })
  studentsCount: number;

  @ApiProperty({
    description: 'Creation date',
    example: '2023-05-01T12:00:00Z',
  })
  createdAt: Date;
}

export class CourseDetailDto {
  @ApiProperty({
    description: 'Course ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  id: string;

  @ApiProperty({
    description: 'Course title',
    example: 'Introduction to Programming',
  })
  title: string;

  @ApiProperty({
    description: 'Course description',
    example:
      'This course provides an introduction to programming concepts using JavaScript.',
  })
  description: string;

  @ApiProperty({
    description: 'Teacher ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  teacherId: string;

  @ApiProperty({
    description: 'Teacher name',
    example: 'John Doe',
  })
  teacherName: string;

  @ApiProperty({
    description: 'Course materials',
    type: [MaterialDto],
  })
  materials: MaterialDto[];

  @ApiProperty({
    description: 'Course assignments',
    type: [AssignmentDto],
  })
  assignments: AssignmentDto[];

  @ApiProperty({
    description: 'Creation date',
    example: '2023-05-01T12:00:00Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Update date',
    example: '2023-05-01T12:00:00Z',
  })
  updatedAt: Date;
}

export class CourseListResponseDto {
  @ApiProperty({
    description: 'List of courses',
    type: [CourseListItemDto],
  })
  items: CourseListItemDto[];
}

export class CreateCourseResponseDto {
  @ApiProperty({
    description: 'Success status',
    example: true,
  })
  success: boolean;

  @ApiProperty({
    description: 'Response message',
    example: 'Kurs muvaffaqiyatli yaratildi',
  })
  message: string;

  @ApiProperty({
    description: 'Course information',
    type: CourseListItemDto,
  })
  course: CourseListItemDto;
}
