import { IsString, Length } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateCourseDto {
  @ApiProperty({
    description: 'Course title',
    example: 'Introduction to Programming',
    minLength: 5,
    maxLength: 100,
  })
  @IsString()
  @Length(5, 100, { message: 'Title must be between 5 and 100 characters' })
  title: string;

  @ApiProperty({
    description: 'Course description',
    example:
      'This course provides an introduction to programming concepts using JavaScript.',
    minLength: 20,
    maxLength: 1000,
  })
  @IsString()
  @Length(20, 1000, {
    message: 'Description must be between 20 and 1000 characters',
  })
  description: string;
}
