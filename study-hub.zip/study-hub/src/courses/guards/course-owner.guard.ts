import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import { CoursesService } from '../courses.service';
import { UserRole } from '../../common/decorators/roles.decorator';

@Injectable()
export class CourseOwnerGuard implements CanActivate {
  constructor(private coursesService: CoursesService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('User not authenticated');
    }

    if (user.role === UserRole.ADMIN) {
      return true;
    }

    const courseId = request.params.courseId || request.params.id;

    if (!courseId) {
      throw new NotFoundException('Course ID not found');
    }

    const course = await this.coursesService.findOne(courseId);

    if (!course) {
      throw new NotFoundException('Course not found');
    }

    if (course.teacherId !== user.id) {
      throw new ForbiddenException(
        'You do not have permission to access this course',
      );
    }

    return true;
  }
}
