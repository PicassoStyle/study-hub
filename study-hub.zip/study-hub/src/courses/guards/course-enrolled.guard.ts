import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import { CoursesService } from '../courses.service';
import { UserRole } from '../../common/decorators/roles.decorator';

@Injectable()
export class CourseEnrolledGuard implements CanActivate {
  constructor(private coursesService: CoursesService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('User not authenticated');
    }

    if (user.role === UserRole.TEACHER || user.role === UserRole.ADMIN) {
      return true;
    }

    const assignmentId = request.params.assignmentId;

    if (!assignmentId) {
      throw new NotFoundException('Assignment ID not found');
    }

    const isEnrolled = await this.coursesService.isStudentEnrolledInAssignment(
      user.id,
      assignmentId,
    );

    if (!isEnrolled) {
      throw new ForbiddenException('You are not enrolled in this course');
    }

    return true;
  }
}
