import {
  Injectable,
  ConflictException,
  BadRequestException,
  UnauthorizedException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { UsersService } from '../users/users.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { VerifySmsDto } from './dto/verify-sms.dto';
import { SmsService } from '../common/mocks/sms.service';
import { EmailService } from '../common/mocks/email.service';
import { UserRole } from '../common/decorators/roles.decorator';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
    private configService: ConfigService,
    private smsService: SmsService,
    private emailService: EmailService,
  ) {}

  async register(registerDto: RegisterDto) {
    const existingEmail = await this.usersService.findOneByEmail(
      registerDto.email,
    );
    if (existingEmail) {
      throw new ConflictException('Email already exists');
    }

    const existingPhone = await this.usersService.findOneByPhoneNumber(
      registerDto.phoneNumber,
    );
    if (existingPhone) {
      throw new ConflictException('Phone number already exists');
    }

    const user = await this.usersService.create({
      fullName: registerDto.fullName,
      email: registerDto.email,
      password: registerDto.password,
      phoneNumber: registerDto.phoneNumber,
      role: UserRole.STUDENT,
    });

    await this.smsService.sendVerificationCode(user.phoneNumber);

    await this.emailService.sendVerificationEmail(user.email, user.id);

    return {
      success: true,
      message:
        "Ro'yxatdan o'tish muvaffaqiyatli amalga oshirildi. Iltimos, telefoningizga yuborilgan kodni tasdiqlang.",
      userId: user.id,
    };
  }

  async verifySms(verifySmsDto: VerifySmsDto) {
    const user = await this.usersService.findOneByPhoneNumber(
      verifySmsDto.phone_number,
    );
    if (!user) {
      throw new NotFoundException('User not found with this phone number');
    }

    const isValid = await this.smsService.verifyCode(
      verifySmsDto.phone_number,
      verifySmsDto.code,
    );
    if (!isValid) {
      throw new BadRequestException('Invalid or expired verification code');
    }

    await this.usersService.markPhoneAsVerified(user.id);

    return {
      success: true,
      message:
        'Telefon raqam tasdiqlandi. Endi email manzilingizni tasdiqlashingiz kerak.',
    };
  }

  async verifyEmail(token: string) {
    const userId = await this.emailService.verifyToken(token);
    if (!userId) {
      throw new BadRequestException('Invalid or expired verification token');
    }

    await this.usersService.markEmailAsVerified(userId);

    return {
      success: true,
      message: 'Email manzil tasdiqlandi. Endi tizimga kirishingiz mumkin.',
    };
  }

  async login(loginDto: LoginDto) {
    const user = await this.usersService.findOneByEmail(loginDto.email);
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const isPasswordValid = await user.comparePassword(loginDto.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (!user.isEmailVerified && !user.isPhoneVerified) {
      throw new UnauthorizedException(
        'Account is not verified. Please verify your email or phone number',
      );
    }

    const [accessToken, refreshToken] = await Promise.all([
      this.generateAccessToken(user.id, user.email, user.role),
      this.generateRefreshToken(user.id),
    ]);

    return {
      success: true,
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        isVerified: user.isEmailVerified || user.isPhoneVerified,
      },
    };
  }

  async generateAccessToken(
    userId: string,
    email: string,
    role: UserRole,
  ): Promise<string> {
    const payload = { sub: userId, email, role };
    return this.jwtService.sign(payload, {
      secret: this.configService.get('jwt.secret'),
      expiresIn: this.configService.get('jwt.expiresIn'),
    });
  }

  async generateRefreshToken(userId: string): Promise<string> {
    const payload = { sub: userId };
    return this.jwtService.sign(payload, {
      secret: this.configService.get('jwt.refreshSecret'),
      expiresIn: this.configService.get('jwt.refreshExpiresIn'),
    });
  }

  async refreshToken(token: string) {
    try {
      const payload = this.jwtService.verify(token, {
        secret: this.configService.get('jwt.refreshSecret'),
      });

      const user = await this.usersService.findOneById(payload.sub);

      const accessToken = await this.generateAccessToken(
        user.id,
        user.email,
        user.role,
      );

      return {
        success: true,
        accessToken,
      };
    } catch (error) {
      throw new UnauthorizedException('Invalid refresh token');
    }
  }
}
