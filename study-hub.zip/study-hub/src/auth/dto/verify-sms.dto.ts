import { IsString, Length, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class VerifySmsDto {
  @ApiProperty({
    description: 'User phone number',
    example: '+998901234567',
  })
  @IsString()
  @Matches(/^\+998[0-9]{9}$/, {
    message: 'Phone number must be in format +998XXXXXXXXX',
  })
  phone_number: string;

  @ApiProperty({
    description: 'Verification code',
    example: '123456',
  })
  @IsString()
  @Length(6, 6, { message: 'Verification code must be exactly 6 digits' })
  @Matches(/^[0-9]{6}$/, {
    message: 'Verification code must contain only digits',
  })
  code: string;
}
