import { IsString, IsEmail, Length, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({
    description: 'User full name',
    example: 'Diyore ake',
    minLength: 3,
    maxLength: 50,
  })
  @IsString()
  @Length(3, 50, { message: 'Full name must be between 3 and 50 characters' })
  fullName: string;

  @ApiProperty({
    description: 'User email',
    example: 'diyor.akee@example.com',
  })
  @IsEmail({}, { message: 'Email must be a valid email address' })
  email: string;

  @ApiProperty({
    description: 'User password',
    example: 'Password123',
    minLength: 8,
    maxLength: 20,
  })
  @IsString()
  @Length(8, 20, { message: 'Password must be between 8 and 20 characters' })
  @Matches(/^(?=.*[0-9])(?=.*[A-Z])/, {
    message: 'Password must contain at least 1 number and 1 uppercase letter',
  })
  password: string;

  @ApiProperty({
    description: 'User phone number',
    example: '+998901234567',
  })
  @IsString()
  @Matches(/^\+998[0-9]{9}$/, {
    message: 'Phone number must be in format +998XXXXXXXXX',
  })
  phoneNumber: string;
}
