import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';
import { v4 as uuid } from 'uuid';

@Injectable()
export class EmailService {
  private transporter: nodemailer.Transporter;
  private verificationTokens: Map<string, { userId: string; expiresAt: Date }> =
    new Map();

  constructor(private configService: ConfigService) {
    this.transporter = nodemailer.createTransport({
      host: this.configService.get('email.host'),
      port: this.configService.get('email.port'),
      secure: this.configService.get('email.secure'),
      auth: {
        user: this.configService.get('email.auth.user'),
        pass: this.configService.get('email.auth.pass'),
      },
    });
  }

  async sendVerificationEmail(email: string, userId: string): Promise<string> {
    const token = uuid();

    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    this.verificationTokens.set(token, { userId, expiresAt });

    const verificationUrl = `http://localhost:3000/api/auth/verify-email/${token}`;

    const mailOptions = {
      from: this.configService.get('email.from'),
      to: email,
      subject: 'Email tasdiqlash - StudyHUB',
      html: `
        <h2>StudyHUB platformasida ro'yxatdan o'tganingiz uchun rahmat!</h2>
        <p>Iltimos, quyidagi havolani bosib, elektron pochta manzilingizni tasdiqlang:</p>
        <a href="${verificationUrl}" style="display: inline-block; background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Email manzilni tasdiqlash</a>
        <p>Yoki quyidagi havolani brauzeringizga nusxalang:</p>
        <p>${verificationUrl}</p>
        <p>Ushbu havola 24 soat davomida amal qiladi.</p>
      `,
    };

    console.log(
      `[Email Mock] Sending verification email to ${email} with token ${token}`,
    );
    console.log(`[Email Mock] Verification URL: ${verificationUrl}`);

    return token;
  }

  async verifyToken(token: string): Promise<string | null> {
    const verification = this.verificationTokens.get(token);

    if (!verification) {
      return null;
    }

    if (verification.expiresAt < new Date()) {
      this.verificationTokens.delete(token);
      return null;
    }

    this.verificationTokens.delete(token);

    return verification.userId;
  }
}
