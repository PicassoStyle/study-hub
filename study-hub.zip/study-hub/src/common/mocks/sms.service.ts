import { Injectable } from '@nestjs/common';

@Injectable()
export class SmsService {
  private verificationCodes: Map<string, { code: string; expiresAt: Date }> =
    new Map();

  async sendVerificationCode(phoneNumber: string): Promise<string> {
    const code = Math.floor(100000 + Math.random() * 900000).toString();

    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 15);

    this.verificationCodes.set(phoneNumber, { code, expiresAt });

    console.log(
      `[SMS Mock] Sending verification code ${code} to ${phoneNumber}`,
    );

    return code;
  }

  async verifyCode(phoneNumber: string, code: string): Promise<boolean> {
    const verification = this.verificationCodes.get(phoneNumber);

    if (!verification) {
      return false;
    }

    if (verification.expiresAt < new Date()) {
      this.verificationCodes.delete(phoneNumber);
      return false;
    }

    const isValid = verification.code === code;

    if (isValid) {
      this.verificationCodes.delete(phoneNumber);
    }

    return isValid;
  }
}
