import { ApiProperty } from '@nestjs/swagger';
import { UserRole } from '../../common/decorators/roles.decorator';

export class UserResponseDto {
  @ApiProperty({
    description: 'User ID',
    example: '8f7b9c1a-2d3e-4f5a-6b7c-8d9e0f1a2b3c',
  })
  id: string;

  @ApiProperty({
    description: 'User full name',
    example: 'DIyor Aka',
  })
  fullName: string;

  @ApiProperty({
    description: 'User email',
    example: 'diyor.akee@example.com',
  })
  email: string;

  @ApiProperty({
    description: 'User phone number',
    example: '+998901234567',
  })
  phoneNumber: string;

  @ApiProperty({
    description: 'User role',
    enum: UserRole,
    example: UserRole.STUDENT,
  })
  role: UserRole;

  @ApiProperty({
    description: 'Whether the user email is verified',
    example: true,
  })
  isEmailVerified: boolean;

  @ApiProperty({
    description: 'Whether the user phone is verified',
    example: true,
  })
  isPhoneVerified: boolean;

  @ApiProperty({
    description: 'Creation date',
    example: '2023-05-01T12:00:00Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Last update date',
    example: '2023-05-01T12:00:00Z',
  })
  updatedAt: Date;
}
