import { IsOptional, IsString, Length } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateProfileDto {
  @ApiProperty({
    description: 'User full name',
    example: 'John Doe',
    required: false,
  })
  @IsOptional()
  @IsString()
  @Length(3, 50)
  fullName?: string;

  @ApiProperty({
    description: 'User phone number',
    example: '+998901234567',
    required: false,
  })
  @IsOptional()
  @IsString()
  phoneNumber?: string;
}
